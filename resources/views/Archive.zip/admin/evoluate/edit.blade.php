@extends('admin.layouts.admin')
@section('content')

<div class="container-fluid">
<a href="{{route('admin.evolution')}}" class="btn btn-warning">Back</a>
    <div class="row">
      <div class="col-md-8">
        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title">Evoluation</h4>
            <p class="card-category">Evoluate given answer</p>
          </div>
          <div class="card-body">
            <form>
              <div class="row">
               @if ($question->audio!=null)
               <div class="col-md-5">
                <div class="form-group">
                  <label class="bmd-label-floating">Audio Data (Question)</label>
                  <audio controls>
                    <source src="{{asset('assets/question')}}/{{$question->audio}}" type="audio/mp3">
                  Your browser does not support the audio element.
                  </audio>
               
                </div>
              </div>
                   
               @endif
              @if ($question->image!=null)
              <div class="col-md-5">
                <div class="form-group">
                  <label class="bmd-label-floating">Image Data</label>
                  <img src="{{asset('assets/question')}}/{{$question->image}}" class="form-control">
                </div>
              </div>
                  
              @endif
                
              </div>
              <div class="row">
                <div class="col-md-8">
                  <div class="form-group">
                    <label class="bmd-label-floating">Question</label>
                    <p>{{$question->question}}</p>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="bmd-label-floating">Correct Option</label>
                  <p>{{$question->correct?$question->correct:"This Question has no options"}}</p>
                  </div>
                </div>
              </div>
              <div class="row">
               @if ($userdata->data!=null)
               <div class="col-md-5">
                <div class="form-group">
                  <label class="bmd-label-floating">User Data (Answer)</label>
                  <audio controls>
                    <source src="{{asset('assets/uploadedaudio')}}/{{$userdata->data}}" type="audio/mp3">
                  Your browser does not support the audio element.
                  </audio>
                </div>
              </div>
               @else
                   <p>{{$userdata->data}}</p>
               @endif
                
              </div>
   
              <div class="clearfix"></div>
            </form>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-profile">
          <div class="card-avatar">
            <a href="javascript:;">
            <img class="img" src="{{asset('assets/img/faces/marc.jpg')}}" />
            </a>
          </div>
          <div class="card-body">
            {{asset('assets/img/faces/marc.jpg')}}

            <h6 class="card-category text-gray">CEO / Co-Founder</h6>
            <h4 class="card-title">Alec Thompson</h4>
            <p class="card-description">
              Don't be scared of the truth because we need to restart the human foundation in truth And I love you like Kanye loves Kanye I love Rick Owens’ bed design but the back is...
            </p>
            <a href="javascript:;" class="btn btn-primary btn-round">Follow</a>
          </div>
        </div>
      </div>
    </div>
  </div>


@endsection