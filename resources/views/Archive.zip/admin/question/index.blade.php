@extends('admin.layouts.admin')
@section('content')

<div class="container-fluid">
    <div class="row">
    <a class="btn btn-success" href="{{route('admin.addquestion')}}" >Add new question</a>
      <div class="col-md-12">
        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title ">Qusetions</h4>
            <p class="card-category">All Questions</p>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table">
                <thead class=" text-primary">
                  <th>
                    ID
                  </th>
                  <th>
                    Category
                  </th>
                  <th>
                    Sub-Category
                  </th>
                  <th>
                    Question
                  </th>
                  <th>
                    Action
                  </th>
                </thead>
                <tbody>
                
                  @foreach ($questionList as $question)
                  <tr>
                    <td>
                      {{$question->id}}
                    </td>
                    <td>
                      {{$question->type}}
                    </td>
                    <td>
                      {{$question->subtype}}
                    </td>
                    <td style="max-width: 400px;">
                      {{$question->question}}
              
                    </td>
                    <td class="text-primary">
                      <a href="" class="btn btn-primary"><span class="material-icons">preview</span></a>
                      <a href="" class="btn btn-warning"><span class="material-icons">edit </span></a>
                      <a href="{{route('admin.questiondelete',['id'=>$question->id])}}" class="btn btn-danger"><span class="material-icons">delete </span></a>
                    </td>
                  </tr>
                 
                  @endforeach

                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
     
    </div>
  </div>


@endsection